# HmDeepLLangTranslator

![HmDeepLLangTranslator v1.2.1](https://img.shields.io/badge/HmDeepLLangTranslator-v1.2.1-6479ff.svg)
[![MIT](https://img.shields.io/badge/license-MIT-blue.svg?style=flat)](LICENSE)
![Hidemaru 9.25](https://img.shields.io/badge/Hidemaru-v9.25-6479ff.svg)

「DeepL API Free」というずっと無料の翻訳APIを利用して、英語を日本語に、日本語を英語にする

https://秀丸マクロ.net/?page=nobu_tool_hm_deepl_lang_translator_js
